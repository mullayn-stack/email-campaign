# Email Campaign Web App

This project is a simple full‑stack web application for running grassroots email campaigns. It features a public landing page where supporters can quickly send pre‑written emails to a list of recipients, as well as an admin dashboard for managing the campaign content.

## Features

- **Public Landing Page** – Presents a title and tagline, collects the sender’s name, email, postcode and an optional personal note. When the form is submitted, it opens the user’s default mail client with the recipients, subject and body pre‑filled.
- **Admin Dashboard** – A password‑protected page where campaign administrators can update the campaign’s title, tagline, email subject, body template and recipient list. The admin form sends changes to the server via an authenticated API call.
- **Configuration Storage** – Campaign settings are stored in a JSON file on the server. The server exposes endpoints to fetch the current configuration and to update it.
- **Environment Configuration** – Sensitive settings such as the admin username and password are stored in a `.env` file. A `.env.example` template is included.

## File Structure

```
email-campaign/
├── backend/
│   ├── server.js        # Express server with API routes
│   ├── config.json      # Default campaign configuration
│   └── .env.example     # Example environment variables
├── frontend/
│   ├── index.html       # Public landing page
│   ├── admin.html       # Admin dashboard
│   ├── styles.css       # Shared CSS for both pages
│   └── script.js        # Client‑side logic for both pages
├── package.json         # NPM package definition
└── README.md            # This file
```

## Setup

1. **Install Dependencies**  
   Make sure you have [Node.js](https://nodejs.org/) installed. From the project root (`email-campaign`), install the required packages:

   ```bash
   npm install
   ```

2. **Configure Environment**  
   Copy the `.env.example` file to `.env` inside the `backend` directory and adjust the settings as needed:

   ```bash
   cp backend/.env.example backend/.env
   ```

   - `PORT` – The port on which the server will listen (default is `3000`).
   - `ADMIN_USERNAME` – Username required to update the campaign via the admin page.
   - `ADMIN_PASSWORD` – Password required to update the campaign via the admin page.

3. **Run the Server**  
   Start the server using the following command from the project root:

   ```bash
   npm start
   ```

   The server will launch at `http://localhost:3000/` (or whichever port you configured).

## Usage

### Public Landing Page

Navigate to `http://localhost:3000/` in your browser. The page will display the campaign’s title and tagline from `config.json`. Fill out the form with your name, email, postcode (optional) and any personal note. When you click **Send Email**, your default email client will open with the pre‑written message ready to send to the list of recipients.

### Admin Dashboard

Navigate to `http://localhost:3000/admin`. Enter the admin username and password you configured in `.env`. The current campaign settings will load into the form. Modify any fields and click **Save Settings** to update the configuration. The form will send an authenticated request to the server; on success, the JSON file on the server will be updated.

## Notes

- The backend stores campaign data in a local JSON file (`backend/config.json`). In a production deployment you may wish to replace this with a database.
- Authentication for the admin API uses Basic Auth over HTTP. For production use you should enable HTTPS and consider more robust authentication and authorization.
- The `mailto:` link in the landing page relies on the user’s email client. The email is not sent automatically; users must click **Send** in their mail app.
